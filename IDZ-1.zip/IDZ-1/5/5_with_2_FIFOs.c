#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <sysexits.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <locale.h>

#define FIFO1 "FIFO1"
#define FIFO2 "FIFO2"

int main (int argc, char **argv)
{
    setlocale(LC_ALL, "en_US.UTF-8");
    char *fiName, *foName;
    ssize_t ret, wet;
    char str[5000];
    for(int i = 0;i<sizeof(str);i++){
    	str[i] = 0;
    }
    char result [45000];
    for(int i = 0;i<sizeof(result);i++){
    	result[i] = 0;
    }
    char* aa [256];
    int a [256];
    int amount = 0;
    if (argc != 3) {
        printf("Error: found %d arguments. Needs exactly 2", argc-1);
        exit(1);
    }
    fiName = argv[1];
    foName = argv[2];
    pid_t p1, p2, p3;
    int fd1,fd2;
    int ff1, ff2;
    (void)umask(0);

    mknod(FIFO1, S_IFIFO | 0666, 0);
    mknod(FIFO2, S_IFIFO | 0666, 0);
	
    p1 = fork();
    if (p1 == 0) { // Первый
    //printf("first\n");
        ff1 = open (fiName, O_RDONLY);
        if(ff1 < 0) {
		    printf("Can\'t open file \"'%s'\"",fiName);
            exit(-1);
	    } else {
	    ret = read (ff1, str, sizeof(str));
            if (ret < 0)
	    {  
		printf("Can\'t read file \"'%s'\"",fiName);
		exit (-1);
	    }
            if((fd1 = open(FIFO1, O_WRONLY)) < 0){
                printf("Can\'t open FIFO for writing\n");
                exit(-1);
            }
            
            int  size = write(fd1, str, sizeof(str));
            if(size != sizeof(str)){
                printf("Can't write all string to FIFO\n");
                exit(-1);
            }
            
            if(close(fd1) < 0){
                printf("Can\'t close FIFO\n"); 
                exit(-1);
            }
            
        }
        close(ff1);
        exit(0);
    } else {
    
    	p2 = fork();  	 	
    if (p2 == 0) { // Второй
    //printf("second\n");
        char buf[sizeof(str)];
        for(int i = 0;i<sizeof(buf);i++){
    	    buf[i] = 0;
        }
        if((fd1 = open(FIFO1, O_RDONLY)) < 0){
            printf("Can\'t open FIFO for reading\n");
            exit(-1);
        }
        int size = read(fd1, buf, sizeof(str));
        if(size < 0){
            printf("Can\'t read string from FIFO\n");
            exit(-1);
        }
        if(close(fd1) < 0){
            printf("Can\'t close FIFO\n"); 
            exit(-1);
        }
        printf("%s", buf);
        int cur = 0;
        int last = 0;
        int cond = 0;
        for (cur;cur<sizeof(buf);cur++){
            if(cond == 0){
                if((buf[cur] >='A' && buf[cur] <='Z') || (buf[cur] >='a' && buf[cur] <='z')){
                    cond = 1;
                }
                last = cur;
            } else {
                if((buf[cur] >='A' && buf[cur] <='Z') || (buf[cur] >='a' && buf[cur] <='z')|| (buf[cur] >='0' && buf[cur] <='9')){
                    //
                } else {
                    cond = 0;
                    char* x = (char*)malloc(cur-last * sizeof(char));
                    for(int i = last;i<cur;i++){
                        x[i-last] = buf[i];
                    }
                    last = cur;
                    int count = 0;
                    for(int i = 0;i<amount;i++){
                        if (strcmp (x, aa[i])==0){
                            count++;
                            a[i]++;
                        } 
                    }
                    if(count > 0) {
                        //
                    } else {
                        aa[amount] = x;
                        a[amount] = 1;
                        amount++;
                    }
                }
            }
        }
        if(cond!=0){
            char* x = (char*)malloc(cur-last * sizeof(char));
            for(int i = last;i<sizeof(buf);i++){
                x[i-last] = buf[i];
            }
            int count = 0;
            for(int i = 0;i<amount;i++){
                if (strcmp (x, aa[i])==0){
                    count++;
                } 
            }
            if(count > 0) {
                //
            } else {
                aa[amount] = x;
                a[amount] = 1;
                amount++;
            }
        }  
        for(int i = 0;i<amount;i++){
            if(i == 0){
            strcat(result,"\"");
            } else {
            strcat(result," | \"");
            }
            strcat(result,aa[i]);
            strcat(result,"\": ");
	    
            int length = snprintf( NULL, 0, "%d", a[i] );
            char* sx = malloc( length + 1 );
            snprintf( sx, length + 1, "%d", a[i] );
            strcat(result,sx);

        }
        if((fd2 = open(FIFO2, O_WRONLY)) < 0){
            printf("Can\'t open FIFO for writing\n");
            exit(-1);
        }
        size = write(fd2, result, sizeof(result));
        printf("%s\n", result);
            if(size != sizeof(result)){
                printf("Can't write all string to FIFO\n");
                exit(-1);
            }
            if(close(fd2) < 0){
                printf("Can\'t close FIFO\n"); 
                exit(-1);
            }
        exit(0);
    } else {
	wait(0);
        p3 = fork();
       
    if (p3 == 0) { // Третий
    	//printf("third\n");
        char buf[sizeof(result)];
        for(int i = 0;i<sizeof(buf);i++){
    	    buf[i] = 0;
        }
        if((fd2 = open(FIFO2, O_RDONLY)) < 0){
            printf("Can\'t open FIFO for reading\n");
            exit(-1);
        }
        int size = read(fd2, buf, sizeof(result));
        
        if(size < 0){
        
            printf("Can\'t read string from FIFO\n");
            exit(-1);
        }
        if(close(fd2) < 0){
            printf("Can\'t close FIFO\n"); 
            exit(-1);
        }   
        ff2 = open (foName, O_WRONLY);
        if(ff2 <0) {
		    printf("Can\'t open file \"'%s'\"\n",foName);
            exit(-1);
	    } else {
            wet = write (ff2, buf, strlen(buf));
            if (wet < 0)
	    {  
		printf("Can\'t write file \"'%s'\"",fiName);
		exit (-1);
	    }
        }
      
        close(ff2);
        exit(0);
    } else {

    }
   }
}

    if (p1 < 0 || p2 < 0 || p3 < 0){
        printf("Error\n");
        exit(-1);
    }
    return 0;
}
